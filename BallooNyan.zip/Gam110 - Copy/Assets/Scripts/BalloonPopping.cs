﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalloonPopping : MonoBehaviour
{
    public PlayerController pControl;
    public GameObject player;
    public float popBlowback;
    private Rigidbody2D pRb;

    private void Start()
    {
        pRb = player.GetComponent<Rigidbody2D>();
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Obstacle"))
        {
            Destroy(this.gameObject);
            pControl.BalloonsLeft -= 1;
            pRb.velocity = new Vector2( 0, 5) * popBlowback;
        }
    }
}
