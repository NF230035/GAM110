﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tailMoveScript : MonoBehaviour
{
    public Animator animator;

    void Update()
    {
        if (Input.GetKeyDown("left"))
        {
            animator.SetFloat("isMoving", 1);

        }

        if (Input.GetKeyUp("left"))
        {
            animator.SetFloat("isMoving", 0);

        }

        if (Input.GetKeyDown("right"))
        {
            animator.SetFloat("isMoving", 1);

        }

        if (Input.GetKeyUp("right"))
        {
            animator.SetFloat("isMoving", 0);

        }

    }
}
